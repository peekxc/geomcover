

def text():
  return(0)