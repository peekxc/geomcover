from .wset_cover import wset_cover_LP, wset_cover_greedy, wset_cover_sat
from .covers import tangent_neighbor_graph

global_varsc = 10

# from .sc_ext import greedy_set_cover
from .sc_ext import *

from . import set_cover_ext

def testing():
  return(-1)
