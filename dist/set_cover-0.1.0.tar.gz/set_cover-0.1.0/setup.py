# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src/set_cover'}

packages = \
['sc_ext', 'set_cover', 'set_cover.sc_ext']

package_data = \
{'': ['*'],
 'sc_ext': ['extern/pybind11/*',
            'extern/pybind11/detail/*',
            'extern/pybind11/stl/*'],
 'set_cover.sc_ext': ['extern/pybind11/*',
                      'extern/pybind11/detail/*',
                      'extern/pybind11/stl/*']}

install_requires = \
['numpy>=1.22.3,<2.0.0', 'scipy>=1.8.0,<2.0.0']

setup_kwargs = {
    'name': 'set-cover',
    'version': '0.1.0',
    'description': 'Weighted Set Cover algorithms',
    'long_description': None,
    'author': 'Matt Piekenbrock',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
